package com.abbet.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(6, 18, 13)
    private val panel = Color.rgb(13, 35, 25)
    private val green = Color.rgb(32, 224, 112)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 200, 188)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 7, 0, 7)
        }
    }

    private fun button(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(if (label.contains("AB BET")) white else Color.BLACK)
            setBackgroundColor(if (label.contains("AB BET")) panel else green)
            setOnClickListener { action() }
        }
    }

    private fun card(title: String, detail: String, odds: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(panel)
        }
        box.addView(text(title, 17f, white, true))
        box.addView(text(detail, 14f, muted))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listOf("1  $odds", "X  3.20", "2  2.80").forEach { option ->
            val b = Button(this).apply {
                text = option
                textSize = 12f
                setTextColor(Color.BLACK)
                setBackgroundColor(green)
                setOnClickListener {
                    Toast.makeText(this@MainActivity, "Demo kawai: an zaɓi $option", Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(3, 4, 3, 4)
            })
        }
        box.addView(row)
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 8) })
    }

    private fun setup(title: String, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 14, 18, 10)
        }
        root.addView(text("⚽ AB BET", 28f, green, true))
        root.addView(text(title, 22f, white, true))
        root.addView(text(subtitle, 14f, muted))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 0)
        }
        listOf("Home", "Live", "Simulation", "Wallet", "Account").forEach { item ->
            val b = Button(this).apply {
                text = item
                textSize = 10f
                setPadding(2, 4, 2, 4)
                setOnClickListener { openPage(item) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showHome() {
        setup("Your Game. Your Victory.", "DEMO VERSION • Ba ainihin kuɗi ba")
        content.addView(text("BIG MATCHES • BIG WINS", 20f, green, true))
        content.addView(text("Zaɓi wasa don gwada yadda AB Bet zai yi aiki.", 14f, muted))
        card("Manchester City vs Liverpool", "Premier League • Demo match", "2.45")
        card("Real Madrid vs Barcelona", "La Liga • Demo match", "2.10")
        card("Arsenal vs Aston Villa", "Premier League • Demo match", "1.80")
        content.addView(text("Wannan sigar gwaji ce. Wasanni da odds ɗin misali ne.", 13f, muted))
    }

    private fun openPage(page: String) {
        when (page) {
            "Home" -> showHome()
            "Live" -> {
                setup("Live Betting", "Misalan wasanni ne kawai")
                card("Inter Milan vs AC Milan", "Demo • Ba live data ba", "2.00")
                card("PSG vs Marseille", "Demo • Ba live data ba", "1.95")
            }
            "Simulation" -> {
                setup("Simulation Games", "Sigar gwaji")
                card("AB Sim: Lions vs Eagles", "Computer match • Demo", "2.25")
                card("AB Sim: Stars vs United", "Computer match • Demo", "1.90")
            }
            "Wallet" -> {
                setup("Wallet", "Kuɗin gwaji kawai")
                content.addView(text("Demo balance: 0.00 USD", 22f, green, true))
                content.addView(text("Ba a haɗa saka kuɗi ko cire kuɗi na gaske ba.", 15f, muted))
                content.addView(button("Deposit (Demo)") {
                    Toast.makeText(this, "Ba a kunna biyan kuɗi na gaske ba.", Toast.LENGTH_LONG).show()
                })
                content.addView(button("Withdraw (Demo)") {
                    Toast.makeText(this, "Ba a kunna cire kuɗi na gaske ba.", Toast.LENGTH_LONG).show()
                })
            }
            else -> {
                setup("Account", "Rajista za a ƙara a mataki na gaba")
                content.addView(text("AB Bet Account", 20f, green, true))
                content.addView(text("Wannan farkon demo ne. Ba a adana bayanan mutum ba.", 15f, muted))
                content.addView(button("Register (Demo)") {
                    Toast.makeText(this, "Za mu ƙara rajista a mataki na gaba.", Toast.LENGTH_LONG).show()
                })
            }
        }
    }
}
