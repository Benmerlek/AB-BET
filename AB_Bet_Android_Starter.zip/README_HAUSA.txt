AB BET - ANDROID STARTER (DEMO)

Wannan farkon aikin Android ne na AB Bet. Ya ƙunshi fuskar Home, Live, Simulation,
Wallet da Account. Wasanni da odds ɗin misali ne kawai; babu ainihin fare ko kuɗi.

YADDA ZA A BUƊE SHI:
1. A buɗe ZIP ɗin a kwamfuta.
2. A saka Android Studio.
3. A zaɓi Open sannan a zaɓi babban folder mai suna AB_Bet_Android_Starter.
4. A jira Gradle Sync ya kammala.
5. A danna Run domin gwadawa a emulator ko Android phone mai USB debugging.

DON SAMAR DA APK:
A Android Studio, je Build > Build APK(s). Wannan aikin yana buƙatar Android Studio,
JDK da sauke abubuwan Gradle da Android SDK.

ABUBUWAN DA BA A ƘARA BA TUKANAN:
- Rajista da login na gaske
- Database da server
- Real-time sports feed da odds
- Real-money payments da withdrawals
- Admin dashboard
- Lasisi da tantance dokokin ƙasashe

Kada a yi amfani da wannan demo wajen karɓar kuɗin mutane. Sai an kammala tsaro,
gwaji, lasisi da haɗin tsarin biyan kuɗi masu dacewa.
